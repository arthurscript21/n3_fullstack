/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test.n3_fullstack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import test.n3_fullstack.Entity.Usuarios;
import test.n3_fullstack.service.UsuariosService;

/**
 *
 * @author PAAWSA02LC1009
 */
public class UsuarioController {
    @Autowired
    private UsuariosService service;

    @PostMapping("/addUsuario")
    public Usuarios addUsuarios(@RequestBody Usuarios u){
        return service.saveUsuarios(u);
    }

    @PostMapping("/addUsuarios")
    public List<Usuarios> findAllUsuarios(){
        return service.getUsuarios();
    }
}
